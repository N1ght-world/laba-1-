#include <stdio.h>
void main()
{
	puts(" _      __                __       _      __ ");
	puts("| |       |         |      _|     | |       |");
	puts("| |       |         |     |__     | |       |");
	puts(" -                                 -         ");
}